---
layout: post
title: Hadoop Learn Guide
category: MLAdvance
description: Guide of Hadoop Ecosystem.
---
## 前言

大数据越来越火，客户要求越来越高。No废话，开始你的大数据之旅，请在不断的旅途当中为自己画饼！本培训主要针对的是有一定编程基础和有一定数据分析基础的同学，感觉有难度的地方请及时提出。


## 学习路径图

* 1 了解大数据生态圈及准备你的能力

* 2 开始你的装机之艰难旅程

* 3 组件针对性加强训练

* 4 组件定位与深挖

* 5 与时俱进及案例

* 6 数据挖掘相关课题方向加强训练


## 附录

## Other

