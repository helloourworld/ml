---
layout: post
title: 匠心
category: MLAdvance
description:MachineLearningAdvance.
---
# [{{ page.title }}][1]
2015-12-12 By {{ site.author_info }}


[Lijun Yu]:    http://helloourworld.github.io  "Lijun Yu"
[1]:    {{ page.url}}  ({{ page.title }})
