---
---
## 了解傅立叶转换（Fourier transform）

## 频谱分析(spectral analysis)
