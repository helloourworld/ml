---
layout: post
title: Hadoop Mesos
category: MLAdvance
description: mesos和yarn区别
---
## mesos和yarn区别

[mesos和yarn区别](http://blog.csdn.net/xinghun_4/article/details/47907161)

[Getting Started](http://mesos.apache.org/gettingstarted/)

hadoop@NN01.HadoopVM
hadoop@DN01.HadoopVM
hadoop@DN02.HadoopVM
