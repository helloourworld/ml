---
layout: post
title: Hadoop生态圈
category: MLAdvance
description: 如何用形象的比喻描述大数据的技术生态？Hadoop、Hive、Spark 之间是什么关系？
---
## 如何用形象的比喻描述大数据的技术生态？Hadoop、Hive、Spark 之间是什么关系？

请参照知乎原文，[链接](https://www.zhihu.com/question/27974418)