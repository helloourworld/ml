---
layout:     post
title:      How to start applying for Analytics / Data Science Masters in the US Universities?
category: blog
description: Planning a masters program in data science in US? But, not completely aware of the application process? Or afraid of the application process?
---

## Introduction

This aritcle is come from here(http://www.analyticsvidhya.com/blog/2016/07/apply-analytics-data-science-masters-us-universities/?utm_source=feedburner&utm_medium=email&utm_campaign=Feed%3A+AnalyticsVidhya+%28Analytics+Vidhya%29)

## Table of Contents

I have divided the complete application process into 4 phases, precisely as follows:

* 1 Mental Preparation

    >>o Start looking at programs in US Universities

* 2 Taking Pre-requisite Examinations

    >> GRE
    >> TOEFL
    >> Preparing for GRE & TOEFL
    >> How much does GRE & TOEFL score matter in the application?

* 3 Preparing and Submitting Applications

    >> Finalizing Universities (where to go!)
    >> Statement of Purpose (SOP)
    >> A Good Strategy to Follow
    >> Some more advice
    >> Resume / Curriculum Vitae
    >> Letter of Recommendation
    >> Transcripts and Other Formalities

* 4 Selecting from Admits & Flying to US

