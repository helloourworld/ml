#一点点说明

这是[helloourworld.github.io](http://helloourworld.github.io)的blog。你可以到gh-pages branch中查看干净的版本。
* 感谢来自于beiyuu的设计(http://beiyuu.com/)
* 希望你喜欢
* 欢迎star
* 欢迎fork
* Happy hacking ^_^
